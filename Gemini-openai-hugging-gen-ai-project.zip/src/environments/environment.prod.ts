export const environment = {
    production: true,
    GEMINI_API_KEY: 'AIzaSyDX64GTZNzGZXEUHhBnwv-2TzLbEMNLiRA'
  };
  
export const environment = {
    production: false,
    GEMINI_API_KEY: 'AIzaSyDX64GTZNzGZXEUHhBnwv-2TzLbEMNLiRA'
  };
  